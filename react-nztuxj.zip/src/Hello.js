import React from 'react';

export default ({ name }) => <h1> {name}</h1>;
